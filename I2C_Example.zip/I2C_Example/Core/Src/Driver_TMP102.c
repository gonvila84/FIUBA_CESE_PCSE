#include "Driver_TMP102.h"
#include "Driver_TMP102_Port.h"
const uint8_t TMP102_TEMP_REGISTER = 0;
//CMD_REG_TLOW = 0x02,  // Activate LOW alarm register
//CMD_REG_THIGH = 0x03,  // Activate HIGH alarm register


const float LSB_MULTIPLIER_TO_CELSIUS = 0.0625;
struct driverControl
{
	tmp102measureUnit_t tempMeasureUnit;
};

typedef struct driverControl driverControl_t;

driverControl_t tmp102DriverControl;

tmp102temperature_t	TMP102_ConvertTemperatureToMeasureUnit(tmp102transmissionPayload_t * payload);


tmp102configResult_t TMP102_InitDriver(void)
{
	//tmp102configResult_t initDeviceResult = TMP102_SetTemperatureMeasureUnit(resultMeasureUnit);
	TMP102_Port_I2C_Init_Handler();
	//return initDeviceResult;
	TMP102_SetTemperatureMeasureUnit(CELSIUS);
}

void TMP102_SetTemperatureMeasureUnit(tmp102measureUnit_t resultMeasureUnit)
{
	tmp102DriverControl.tempMeasureUnit = resultMeasureUnit;
}



tmp102opsResult_t	TMP102_GetTemperature(tmp102temperature_t * temperature)
{
	tmp102opsResult_t opsResult;
	tmp102transmissionPayload_t payload [2] = {TMP102_TEMP_REGISTER};
	if (TMP102_SEND_SUCCESS == TMP102_Port_I2C_Send	(TMP102_ADDRESS,payload,TMP102_TRANSMISSION_TIMEOUT))
	{
		if (TMP102_RECEIVE_SUCCESS == TMP102_Port_I2C_Receive (TMP102_ADDRESS,payload,TMP102_TRANSMISSION_TIMEOUT))
		{
			*temperature = TMP102_ConvertTemperatureToMeasureUnit(payload);
		}
		else
		{
			opsResult = TMP102_OPS_FAILED;
		}
		opsResult = TMP102_OPS_OK;
	}
	else
	{
		opsResult = TMP102_OPS_FAILED;
	}

	return opsResult;
}

tmp102temperature_t	TMP102_ConvertTemperatureToMeasureUnit(tmp102transmissionPayload_t * payload)
{
	tmp102temperature_t temperature = 0.0;
	int16_t rawData = 0;
	rawData = ((int16_t)payload[0] << 4) | (payload[1] >> 4);

	if (rawData > 0x7FF)
	{
		rawData |= 0xF000;
	}
	temperature = rawData * LSB_MULTIPLIER_TO_CELSIUS;
	if (tmp102DriverControl.tempMeasureUnit == FAHRENHEIT)
	{
		temperature = (temperature * 1.8) + 32;
	}
	return temperature;
}

tmp102opsResult_t TMP102_TestMeasurement (void)
{
	tmp102temperature_t temperature;
	if (TMP102_OPS_FAILED == TMP102_GetTemperature(&temperature))
	{
		return TMP102_OPS_FAILED;
	}
	else
	{
		return TMP102_OPS_OK;
	}
}
/*
tmp102configResult_t TMP102_SetTemperatureAlertMin (tmp102temperature_t minTemperature)
{
	tmp102opsResult_t opsResult;
	tmp102transmissionPayload_t payload [4] = {};
	if (TMP102_SEND_SUCCESS == TMP102_Port_I2C_Send	(TMP102_ADDRESS,payload,TMP102_TRANSMISSION_TIMEOUT))
	{
		if (TMP102_RECEIVE_SUCCESS == TMP102_Port_I2C_Receive (TMP102_ADDRESS,payload,TMP102_TRANSMISSION_TIMEOUT))
		{
			*temperature = TMP102_ConvertTemperatureToMeasureUnit(payload);
		}
		else
		{
			opsResult = TMP102_OPS_FAILED;
		}
		opsResult = TMP102_OPS_OK;
	}
	else
	{
		opsResult = TMP102_OPS_FAILED;
	}

	return opsResult;
}
*/
