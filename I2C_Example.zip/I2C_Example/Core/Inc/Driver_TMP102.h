#ifndef INC_DRIVER_TMP102_H_
#define INC_DRIVER_TMP102_H_

#include <stdint.h>
#include <stdbool.h>

typedef bool bool_t;

enum configResult 					{TMP102_CONFIG_SUCCESS,TMP102_CONFIG_FAIL};
enum communicationResult			{
										 TMP102_SEND_SUCCESS,
									 	 TMP102_SEND_FAILURE,
									 	 TMP102_RECEIVE_SUCCESS,
									 	 TMP102_RECEIVE_FAILURE,
									 	 TMP102_SEND_BUSY,
									 	 TMP102_RECEIVE_BUSY,
									 	 TMP102_SEND_TIMEOUT,
										 TMP102_RECEIVE_TIMEOUT,
									};
enum operationsResult				{
										 TMP102_OPS_OK,
										 TMP102_OPS_FAILED
									};
enum measureUnit 					{CELSIUS, FAHRENHEIT};

typedef enum configResult			tmp102configResult_t;
typedef enum communicationResult	tmp102commResult_t;
typedef enum operationsResult		tmp102opsResult_t;

typedef enum measureUnit			tmp102measureUnit_t;
typedef float						tmp102temperature_t;

typedef uint16_t					tmp102address_t;
typedef uint32_t					tmp102transmissionTimeout_t;
typedef uint8_t						tmp102transmissionPayload_t;

static const tmp102address_t				TMP102_ADDRESS = (0X48 << 1);
static const tmp102transmissionTimeout_t 	TMP102_TRANSMISSION_TIMEOUT = 0xFFFFFFFFU;

//Funciones de configuracion
tmp102configResult_t 	TMP102_InitDriver					(void);
void				 	TMP102_SetTemperatureMeasureUnit	(tmp102measureUnit_t resultMeasureUnit);
//tmp102configResult_t	TMP102_SetTemperatureAlertMin		(tmp102temperature_t minTemperature);
//tmp102configResult_t	TMP102_SetTemperatureAlertMax		(tmp102temperature_t maxTemperature);

//Funciones de transaccion
tmp102opsResult_t		TMP102_GetTemperature (tmp102temperature_t * temperature);
tmp102opsResult_t		TMP102_TestMeasurement	(void);


#endif /* INC_DRIVER_TMP102_H_ */
