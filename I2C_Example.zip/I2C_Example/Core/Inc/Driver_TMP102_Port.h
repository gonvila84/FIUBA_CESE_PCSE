#ifndef INC_DRIVER_TMP102_PORT_H_
#define	INC_DRIVER_TMP102_PORT_H_

#include "Driver_TMP102.h"

tmp102commResult_t 	TMP102_Port_I2C_Send	(tmp102address_t tmp102Address,tmp102transmissionPayload_t * payload,const tmp102transmissionTimeout_t timeout);
tmp102commResult_t	TMP102_Port_I2C_Receive (tmp102address_t tmp102Address,tmp102transmissionPayload_t * payload,const tmp102transmissionTimeout_t timeout);
void TMP102_Port_I2C_Init_Handler (void);


#endif
